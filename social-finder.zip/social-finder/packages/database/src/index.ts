export { prisma } from "./client";
export { PLATFORM_SEEDS } from "./platforms";
export type { PlatformSeed } from "./platforms";
