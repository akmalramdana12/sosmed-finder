export default function HomePage() {
  return (
    <main className="mx-auto max-w-2xl p-8">
      <h1 className="text-2xl font-semibold">Social Finder</h1>
      <p className="mt-2 text-neutral-600">
        Platform opt-in untuk menemukan profil sosial media. Fase 1 (Bootstrap) selesai; UI
        sebenarnya dibangun di fase berikutnya.
      </p>
    </main>
  );
}
