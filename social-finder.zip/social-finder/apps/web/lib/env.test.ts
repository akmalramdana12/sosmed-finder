import { describe, expect, it } from "vitest";
import { loadEnv } from "./env";

const SECRET = "x".repeat(40);

describe("loadEnv", () => {
  it("menolak SESSION_SECRET pendek", () => {
    expect(() => loadEnv({ SESSION_SECRET: "pendek" })).toThrow();
  });

  it("production wajib REDIS_URL", () => {
    expect(() => loadEnv({ NODE_ENV: "production", SESSION_SECRET: SECRET })).toThrow();
  });

  it("cookie secure hanya di production", () => {
    const production = loadEnv({
      NODE_ENV: "production",
      SESSION_SECRET: SECRET,
      REDIS_URL: "redis://localhost:6379",
    });
    const development = loadEnv({ SESSION_SECRET: SECRET });
    expect(production.secureCookies).toBe(true);
    expect(development.secureCookies).toBe(false);
  });

  it("APP_ORIGIN dinormalisasi menjadi daftar origin", () => {
    const env = loadEnv({
      SESSION_SECRET: SECRET,
      APP_ORIGIN: "https://a.example.com/path, http://localhost:3000",
    });
    expect(env.allowedOrigins).toEqual(["https://a.example.com", "http://localhost:3000"]);
  });

  it("TRUST_PROXY default false", () => {
    expect(loadEnv({ SESSION_SECRET: SECRET }).trustProxy).toBe(false);
    expect(loadEnv({ SESSION_SECRET: SECRET, TRUST_PROXY: "true" }).trustProxy).toBe(true);
  });
});
