import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.string().optional(),
  SESSION_SECRET: z.string().min(32, "SESSION_SECRET minimal 32 karakter"),
  REDIS_URL: z.string().min(1).optional(),
  APP_ORIGIN: z.string().min(1).default("http://localhost:3000"),
  TRUST_PROXY: z.string().optional(),
});

export interface AppEnv {
  isProduction: boolean;
  sessionSecret: string;
  redisUrl: string | undefined;
  /** Origin yang diizinkan untuk request yang mengubah state (CSRF). */
  allowedOrigins: string[];
  trustProxy: boolean;
  secureCookies: boolean;
}

export function loadEnv(source: Record<string, string | undefined> = process.env): AppEnv {
  const parsed = envSchema.parse(source);
  const isProduction = parsed.NODE_ENV === "production";
  if (isProduction && !parsed.REDIS_URL) {
    throw new Error("REDIS_URL wajib di production: rate limit harus dibagi antar instance");
  }
  return {
    isProduction,
    sessionSecret: parsed.SESSION_SECRET,
    redisUrl: parsed.REDIS_URL,
    allowedOrigins: parsed.APP_ORIGIN.split(",")
      .map((value) => value.trim())
      .filter((value) => value.length > 0)
      .map((value) => new URL(value).origin),
    trustProxy: parsed.TRUST_PROXY === "true",
    secureCookies: isProduction,
  };
}

let cached: AppEnv | undefined;

/** Lazy agar `next build` tidak membutuhkan secret. */
export function getEnv(): AppEnv {
  cached ??= loadEnv();
  return cached;
}
